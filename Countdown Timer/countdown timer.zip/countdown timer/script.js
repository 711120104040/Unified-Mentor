let timerIntervals = [];
let totalSeconds = [0, 0];
let targetTimes = [0, 0];
let pausedStates = [false, false];

function setTargetTime(timerId) {
    const targetDateTimeInput = document.getElementById(`targetDateTime${timerId}`);
    const targetDateTimeValue = targetDateTimeInput.value;
    const targetDateTime = new Date(targetDateTimeValue).getTime();
    if (!isNaN(targetDateTime)) {
        targetTimes[timerId - 1] = targetDateTime / 1000; // Convert milliseconds to seconds
        totalSeconds[timerId - 1] = targetTimes[timerId - 1] - Math.floor(Date.now() / 1000); // Calculate initial time remaining
        displayTime(timerId);
    } else {
        alert('Invalid date and time format!');
    }
}

function startTimer(timerId) {
    if (!timerIntervals[timerId - 1]) {
        timerIntervals[timerId - 1] = setInterval(() => {
            if (!pausedStates[timerId - 1]) {
                totalSeconds[timerId - 1]--;
                if (totalSeconds[timerId - 1] <= 0) {
                    stopTimer(timerId);
                    playTimerSound();
                    alert(`Timer ${timerId} is up!`);
                } else {
                    displayTime(timerId);
                }
            }
        }, 1000);
    }
}

function stopTimer(timerId) {
    clearInterval(timerIntervals[timerId - 1]);
    timerIntervals[timerId - 1] = null;
    totalSeconds[timerId - 1] = 0;
    displayTime(timerId);
}

function resumeTimer(timerId) {
    pausedStates[timerId - 1] = false;
}

function pauseTimer(timerId) {
    pausedStates[timerId - 1] = true;
}

function resetTimer(timerId) {
    stopTimer(timerId);
    displayTime(timerId);
}

function displayTime(timerId) {
    const days = Math.floor(totalSeconds[timerId - 1] / (24 * 3600));
    const hours = Math.floor((totalSeconds[timerId - 1] % (24 * 3600)) / 3600);
    const minutes = Math.floor((totalSeconds[timerId - 1] % 3600) / 60);
    const seconds = totalSeconds[timerId - 1] % 60;
    const formattedTime = formatTime(days) + ':' + formatTime(hours) + ':' + formatTime(minutes) + ':' + formatTime(seconds);
    document.getElementById(`timer${timerId}`).textContent = formattedTime;
}

function formatTime(time) {
    return (time < 10 ? '0' : '') + time;
}

function playTimerSound() {
    const timerSound = document.getElementById('timerSound');
    timerSound.play();
}
